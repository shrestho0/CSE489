package me.shrestho.tictactoe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
