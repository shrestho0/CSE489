



 
- [-] TODO: Check if account already exists, if not, generate a random display name for that. Keep a flag in the database for that in the 
- [-] TODO: 


- [-] TODO: To Re-Check
- we can search for games that are await playing, if no game there, create a new game and wait for others to search and find us to play.
This can be a solution of the problem of finding online user. We can add another option to wait and re-search, maybe a button named try again [ that will search the most recent online users (maybe 5) and send notification ]

