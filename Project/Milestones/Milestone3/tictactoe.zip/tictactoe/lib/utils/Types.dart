enum GameType {
  ONLINE,
  INVITATION;
}
