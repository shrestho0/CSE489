

#### **Project: `Online tictactoe game`**

Logged in users can play tictactoe online

**Milestone 3**:

- User Authentication [Complete]
  - User Login/Registration
  - User Profile Image Upload
  - User Profile Name Update
  - Authenticate with google

- Join with invitation / Invite Someone [Partial]
  - Complete but the game it self
- Find players online [Incomplete]
  - The concept is ready and will be similar to Invitation Join

